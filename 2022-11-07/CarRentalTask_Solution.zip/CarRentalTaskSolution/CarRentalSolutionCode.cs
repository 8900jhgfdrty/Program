﻿using System;
using System.Collections.Generic;

namespace CarRentalService
{
    internal class Program
    {
        // This is the data structure that stores the current line from the input. 
        // (Stores only on line that contains the data: plate number, rent start date, rent end date.)
        public struct RentCar
        {
            public string plateNumber;
            public int startDate;
            public int endDate;
        }

        // This struct collects computed data for Task2
        /* It contains the cars plate number once, 
         * the number of days that they were used, 
         * how many times they were rented 
        */
        public struct Task2Helper
        {
            public List<string> plateNumber;
            public List<int> numberOfDays;
            // for task5
            public List<int> countOfRent;
        }

        static void Main(string[] args)
        {
            // Getting the number of lines
            int carNumbers = Convert.ToInt32(Console.ReadLine());

            // Initialization of the RentCar struct it always only stores one car's details
            RentCar car = new RentCar();
            int firstTaskResult = 0;

            // Initialization of the Task2Helper struct and its lists
            Task2Helper task2Helper = new Task2Helper();
            task2Helper.plateNumber = new List<string>();
            task2Helper.numberOfDays = new List<int>();
            // for task5
            task2Helper.countOfRent = new List<int>();
            int secondTaskResultIndex = 0;

            // Helper array for Task3
            /* This contains the days of the month from 1 to 30
             * (it uses the indexes as the days and their value contains
             * the count of the rented cars on that particular day)
            */
            int[] task3Helper = new int[30];
            int thirdTaskResultIndex = 0;

            // reading the data on a car line by line
            for (int i = 0; i < carNumbers; i++)
            {
                // Get 1 line
                string input = Console.ReadLine();
                car.plateNumber = input.Split(" ")[0];
                car.startDate = Convert.ToInt32(input.Split(" ")[1]);
                car.endDate = Convert.ToInt32(input.Split(" ")[2]);

                // call for firstTask function, returns a number
                firstTaskResult += firstTask(car.startDate, car.endDate);
                // call for secondTask function, returns a Task2Helper type
                task2Helper = secondTask(task2Helper, car.plateNumber, car.startDate, car.endDate);
                // call for thirdTask function, returns an int array
                task3Helper = thirdTask(task3Helper, car.startDate, car.endDate);
            }

            // TASK1 output
            Console.WriteLine("#\n" + firstTaskResult);

            // TASK2 + max value selection with the help of the index + output
            Console.WriteLine("#");
            for (int i = 1; i < task2Helper.numberOfDays.Count; i++)
                if (task2Helper.numberOfDays[i] > task2Helper.numberOfDays[secondTaskResultIndex])
                    secondTaskResultIndex = i;
            Console.WriteLine(task2Helper.plateNumber[secondTaskResultIndex]);

            // TASK3 + max value selection with the help of the index + output
            Console.WriteLine("#");
            for (int i = 0; i < task3Helper.Length; i++)
                if (task3Helper[i] > task3Helper[thirdTaskResultIndex])
                    thirdTaskResultIndex = i;
            Console.WriteLine(thirdTaskResultIndex + 1);

            //checker for how many cars were rented on each day of the month
            //for (int i = 0; i < task3Helper.Length; i++)
                //Console.Write(task3Helper[i] + " ");

            // TASK4 + call the fourthTask's function that prints out the output
            Console.WriteLine("#");
            fourthTask(task3Helper, thirdTaskResultIndex);
            Console.WriteLine("");

            // TASK5 + call the fifthTask's function that prints out the output
            Console.WriteLine("#");
            fifthTask(task2Helper);
        }

        // TASK1 returns the number of days that the given car was rented at that period
        public static int firstTask(int startDate, int endDate)
        {
            return endDate - startDate + 1;
        }
    
        // TASK2 returns a list containing each car once and the number of days they were rented and the number of times they were rented
        public static Task2Helper secondTask(Task2Helper tmpTask2Helper, string plateNumber, int startDate, int endDate)
        {
            if (!tmpTask2Helper.plateNumber.Contains(plateNumber)){
                tmpTask2Helper.plateNumber.Add(plateNumber);
                tmpTask2Helper.numberOfDays.Add(endDate - startDate + 1);
                // for task5
                tmpTask2Helper.countOfRent.Add(1);
            }
            else
            {
                int tmpIndex = tmpTask2Helper.plateNumber.IndexOf(plateNumber);
                tmpTask2Helper.numberOfDays[tmpIndex] += endDate - startDate + 1;
                // for task5
                tmpTask2Helper.countOfRent[tmpIndex] += 1;
            }
            return tmpTask2Helper;
        }
    
        // TASK3 returns an int array with the count of how many cars were rented on each day
        public static int[] thirdTask(int[] task3Helper, int startDate, int endDate)
        {
            for (int i = startDate - 1; i <= endDate - 1; i++)
                task3Helper[i]++;
            return task3Helper;
        }

        // TASK4 prints out a list of days (indexes) on which more car were rented than on any days in the month before
        public static void fourthTask(int[] task3Helper, int thirdTaskResultIndex)
        {
            bool moreWereRentedBefore = false;
            for (int i = 1; i <= thirdTaskResultIndex; i++)
                if (task3Helper[i] > task3Helper[i - 1])
                {
                    for (int j = 0; j <= i - 1; j++)
                    {
                        if (task3Helper[j] > task3Helper[i - 1])
                            moreWereRentedBefore = true;
                    }
                    if (!moreWereRentedBefore)
                    {
                        Console.Write(i + 1 + " ");
                    }
                    else
                    {
                        moreWereRentedBefore = false;
                    }
                }          
        }

        // TASK5 prints out the list of cars containing their plat number, the count of rent, and the number of days they were rented
        public static void fifthTask(Task2Helper task2Helper)
        {
            // lets go back and add the count to the task2helper structure with this we can reduce the run time
            for (int i = 0; i < task2Helper.plateNumber.Count; i++)
                Console.WriteLine(task2Helper.plateNumber[i] + " " + task2Helper.countOfRent[i] + " " + task2Helper.numberOfDays[i]);
        }
    }
}